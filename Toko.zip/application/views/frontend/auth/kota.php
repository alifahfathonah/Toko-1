<?php
$style_kota='class="form-control" id="kota_id"';
echo form_dropdown("kota_id",$kota,'',$style_kota);
?>
