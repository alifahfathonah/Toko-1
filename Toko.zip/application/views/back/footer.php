<footer class="main-footer no-print">
  <div class="pull-right hidden-xs"><b>Template Version</b> 2.0</div>
  <strong>Copyright &copy; 2019 <a href="ajcomm.id">AdminLTE</a>.</strong> All rights reserved.
  Theme by <a href="http://almsaeedstudio.com">Almsaeed Studio</a>
</footer>
